import bpy
import math
import os
from mathutils import Vector

OUT = '/mnt/agents/output/app'
ASSETS = os.path.join(OUT, 'assets')
os.makedirs(ASSETS, exist_ok=True)

bpy.ops.object.select_all(action='SELECT')
bpy.ops.object.delete(use_global=False)
for block in bpy.data.materials:
    bpy.data.materials.remove(block)

# Coordinate contract: metres, Z up, front -Y, road at Z=0.
scene = bpy.context.scene
scene.unit_settings.system = 'METRIC'
scene.unit_settings.scale_length = 1.0
scene.render.fps = 24
scene.frame_start = 1
scene.frame_end = 144

bus_col = bpy.data.collections.new('BUS • componentes editables')
scene.collection.children.link(bus_col)
stage_col = bpy.data.collections.new('STUDIO • no exportar')
scene.collection.children.link(stage_col)


def move_to(obj, collection):
    for c in list(obj.users_collection):
        c.objects.unlink(obj)
    collection.objects.link(obj)
    return obj


def material(name, color, metallic=0.0, roughness=0.4, emission=None, strength=0.0):
    m = bpy.data.materials.new(name)
    m.use_nodes = True
    p = m.node_tree.nodes.get('Principled BSDF')
    p.inputs['Base Color'].default_value = (*color, 1)
    p.inputs['Metallic'].default_value = metallic
    p.inputs['Roughness'].default_value = roughness
    if emission:
        p.inputs['Emission Color'].default_value = (*emission, 1)
        p.inputs['Emission Strength'].default_value = strength
    m.diffuse_color = (*color, 1)
    return m

navy = material('Carrocería | azul profundo', (0.012, 0.032, 0.052), 0.72, 0.25)
panel = material('Paneles | azul grafito', (0.022, 0.065, 0.09), 0.62, 0.3)
black = material('Sellos y parrillas | negro', (0.004, 0.007, 0.01), 0.2, 0.38)
glass = material('Cristal | azul humo', (0.014, 0.055, 0.078), 0.38, 0.18)
mirror_mat = material('Espejos | cromo oscuro', (0.2, 0.32, 0.38), 0.95, 0.08)
cyan = material('Acento | cian Enrutados', (0.0, 0.65, 0.72), 0.5, 0.24, (0.0, 0.7, 0.8), 1.3)
cyan_dim = material('Acento | cian oscuro', (0.0, 0.19, 0.24), 0.6, 0.28)
white = material('Marcas | blanco frío', (0.68, 0.85, 0.9), 0.2, 0.35)
rubber = material('Neumáticos | goma', (0.008, 0.009, 0.012), 0.0, 0.72)
rim = material('Llantas | aluminio', (0.22, 0.3, 0.34), 0.88, 0.23)
led = material('LED | blanco azulado', (0.5, 0.9, 1.0), 0.15, 0.2, (0.35, 0.85, 1.0), 5.0)
amber = material('LED | ámbar', (1.0, 0.28, 0.015), 0.1, 0.25, (1.0, 0.22, 0.005), 4.0)
red = material('LED | rojo trasero', (0.5, 0.005, 0.008), 0.1, 0.25, (1.0, 0.0, 0.005), 3.0)

root = bpy.data.objects.new('BUS_ROOT • avance -Y', None)
bus_col.objects.link(root)
root.empty_display_type = 'PLAIN_AXES'
root.empty_display_size = 0.8
root['descripcion'] = 'Bus urbano moderno original. Frente -Y; unidades en metros.'
root['animacion_scroll'] = 'Approach: 6 s; mapear scroll 0..1 al tiempo 0..6.'
root['etapa'] = 'Modelo base sólido; partículas y desintegración se añaden en WebGL.'


def finish(obj, name, mat=None, parent=root, collection=bus_col):
    obj.name = name
    move_to(obj, collection)
    if mat:
        obj.data.materials.append(mat)
    if parent:
        obj.parent = parent
    return obj


def box(name, loc, dims, mat, bevel=0.04, parent=root, collection=bus_col):
    bpy.ops.mesh.primitive_cube_add(size=1, location=loc)
    o = bpy.context.object
    o.dimensions = dims
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    finish(o, name, mat, parent, collection)
    if bevel > 0:
        mod = o.modifiers.new('Bordes suavizados', 'BEVEL')
        mod.width = bevel
        mod.segments = 3
        mod = o.modifiers.new('Normales ponderadas', 'WEIGHTED_NORMAL')
        mod.keep_sharp = True
    return o


def cylinder(name, loc, radius, depth, mat, axis='Z', vertices=48, parent=root):
    bpy.ops.mesh.primitive_cylinder_add(vertices=vertices, radius=radius, depth=depth, location=loc)
    o = bpy.context.object
    if axis == 'X':
        o.rotation_euler[1] = math.pi / 2
    elif axis == 'Y':
        o.rotation_euler[0] = math.pi / 2
    finish(o, name, mat, parent)
    bevel = o.modifiers.new('Canto mecánico', 'BEVEL')
    bevel.width = min(0.018, depth * 0.15)
    bevel.segments = 2
    o.modifiers.new('Normales', 'WEIGHTED_NORMAL')
    return o


def rod(name, a, b, radius, mat, parent=root):
    a, b = Vector(a), Vector(b)
    d = b - a
    o = cylinder(name, (a + b) / 2, radius, d.length, mat, 'Z', 16, parent)
    o.rotation_euler = d.to_track_quat('Z', 'Y').to_euler()
    return o


def text_obj(name, body, loc, size, mat, rotation=(math.pi / 2, 0, 0), align='CENTER'):
    curve = bpy.data.curves.new(name, 'FONT')
    curve.body = body
    curve.align_x = align
    curve.align_y = 'CENTER'
    curve.size = size
    curve.extrude = 0.0008
    curve.bevel_depth = 0.0004
    o = bpy.data.objects.new(name, curve)
    bus_col.objects.link(o)
    o.location = loc
    o.rotation_euler = rotation
    o.parent = root
    curve.materials.append(mat)
    return o


def torus(name, loc, major, minor, mat, parent):
    bpy.ops.mesh.primitive_torus_add(major_radius=major, minor_radius=minor, major_segments=48, minor_segments=12, location=loc)
    o = bpy.context.object
    o.rotation_euler[1] = math.pi / 2
    finish(o, name, mat, parent)
    for p in o.data.polygons:
        p.use_smooth = True
    return o

# Main masses: a low-floor city bus with a broad, nearly vertical face.
box('Carrocería principal', (0, 0, 1.63), (2.55, 8.8, 2.46), navy, 0.16)
box('Zócalo inferior', (0, 0, 0.58), (2.57, 8.58, 0.42), panel, 0.09)
box('Techo redondeado', (0, 0.05, 2.91), (2.48, 8.58, 0.28), panel, 0.13)
box('Franja lateral cian', (0, 0, 1.18), (2.585, 8.5, 0.075), cyan_dim, 0.02)

# Front glazing and destination display.
box('Parabrisas | marco', (0, -4.407, 2.04), (2.29, 0.075, 1.46), black, 0.13)
box('Parabrisas | cristal', (0, -4.451, 2.055), (2.15, 0.025, 1.31), glass, 0.11)
box('Parabrisas | división', (0, -4.469, 2.055), (0.025, 0.018, 1.20), black, 0.008)
box('Display de ruta | marco', (0, -4.42, 2.77), (1.95, 0.08, 0.25), black, 0.05)
box('Display de ruta | fondo', (0, -4.467, 2.775), (1.78, 0.018, 0.16), glass, 0.025)
text_obj('Display ENRUTADOS', 'ENRUTADOS', (0, -4.484, 2.777), 0.115, cyan)
for x in (-0.76, 0.76):
    box('Luz superior ámbar', (x, -4.438, 2.82), (0.42, 0.035, 0.045), amber, 0.018)

# Wipers lie just above the glass.
for s in (-1, 1):
    rod('Limpiaparabrisas | brazo', (s * 0.26, -4.49, 1.43), (s * 0.70, -4.49, 1.93), 0.012, black)
    rod('Limpiaparabrisas | hoja', (s * 0.45, -4.503, 1.79), (s * 0.92, -4.503, 2.02), 0.014, black)

# Front bumper, grille, lights and badge.
box('Parachoques frontal', (0, -4.405, 0.64), (2.40, 0.19, 0.31), black, 0.08)
box('Parrilla central', (0, -4.515, 0.77), (1.14, 0.035, 0.30), black, 0.05)
for z in (0.68, 0.76, 0.84):
    box('Lama de parrilla', (0, -4.538, z), (0.98, 0.02, 0.018), rim, 0.006)
for s in (-1, 1):
    box('Farol | carcasa', (s * 0.85, -4.46, 0.96), (0.61, 0.075, 0.24), black, 0.065)
    box('Farol | firma LED', (s * 0.85, -4.507, 1.035), (0.49, 0.026, 0.035), led, 0.014)
    for dx in (-0.13, 0.02, 0.15):
        cylinder('Farol | óptica', (s * 0.85 + dx, -4.51, 0.925), 0.047, 0.025, led, 'Y', 24)
    box('Intermitente ámbar', (s * 1.08, -4.48, 1.08), (0.16, 0.035, 0.035), amber, 0.012)

# Geometric double-chevron emblem.
for i, x in enumerate((-0.10, 0.02)):
    o = box('Emblema cian', (x, -4.555, 1.12), (0.15, 0.022, 0.055), cyan, 0.012)
    o.rotation_euler[1] = -0.45
text_obj('Marca frontal', 'ENRUTADOS', (0, -4.54, 0.535), 0.075, white)

# Side windows, pillars and lower service panels.
window_y = [-3.42, -2.30, -1.18, -0.06, 1.06, 2.18, 3.30]
for s in (-1, 1):
    x = s * 1.283
    for i, y in enumerate(window_y):
        box(f'Ventana lateral {s:+d}.{i+1}', (x, y, 2.08), (0.035, 1.00, 1.18), glass, 0.055)
        box('Reflejo superior ventana', (s * 1.306, y, 2.56), (0.012, 0.88, 0.018), cyan_dim, 0.005)
    box('Cintura lateral luminosa', (s * 1.305, 0.12, 1.29), (0.02, 8.15, 0.028), cyan, 0.008)
    for y in (-3.55, -1.55, 0.45, 2.45):
        box('Panel inferior lateral', (s * 1.295, y, 0.92), (0.025, 1.65, 0.37), panel, 0.025)
    for y in (3.18, 3.34, 3.50, 3.66):
        box('Rejilla motor lateral', (s * 1.315, y, 0.93), (0.018, 0.055, 0.26), black, 0.008)

# Two double passenger doors on the right side of the vehicle.
for door_index, y in enumerate((-2.87, 0.62)):
    x = -1.327
    box(f'Puerta {door_index+1} | marco', (x, y, 1.54), (0.052, 1.15, 1.94), black, 0.045)
    for dy in (-0.275, 0.275):
        box('Puerta | hoja de cristal', (x - 0.032, y + dy, 1.63), (0.025, 0.49, 1.57), glass, 0.04)
        box('Puerta | zócalo', (x - 0.034, y + dy, 0.69), (0.026, 0.49, 0.20), panel, 0.02)
    box('Puerta | eje central', (x - 0.055, y, 1.54), (0.025, 0.035, 1.85), rim, 0.005)
    box('Puerta | borde de seguridad', (x - 0.06, y - 0.52, 1.50), (0.02, 0.025, 1.70), amber, 0.006)

# Mirror assemblies with real support arms.
for s in (-1, 1):
    rod('Espejo | brazo superior', (s * 1.22, -3.94, 2.52), (s * 1.56, -4.10, 2.42), 0.027, black)
    rod('Espejo | brazo inferior', (s * 1.22, -3.94, 1.82), (s * 1.56, -4.10, 1.87), 0.027, black)
    box('Espejo | carcasa', (s * 1.58, -4.11, 2.14), (0.22, 0.26, 0.72), black, 0.09)
    box('Espejo | superficie', (s * 1.58, -4.252, 2.14), (0.16, 0.025, 0.57), mirror_mat, 0.065)
    box('Espejo | acento', (s * 1.58, -4.255, 1.85), (0.11, 0.015, 0.025), cyan, 0.007)

# Roof equipment.
box('Unidad de clima', (0, 1.25, 3.13), (1.58, 2.35, 0.27), black, 0.12)
for y in [0.45 + i * 0.18 for i in range(10)]:
    box('Rejilla de clima', (0, y, 3.277), (1.30, 0.055, 0.018), rim, 0.007)
box('Antena conectividad', (0, -2.15, 3.13), (0.34, 0.52, 0.16), panel, 0.07)

# Wheels are independent hierarchies, ready for rotation and later particle sampling.
wheel_roots = []
for y, axle in ((-2.78, 'delantero'), (2.72, 'trasero')):
    for s, side in ((-1, 'izquierdo'), (1, 'derecho')):
        w = bpy.data.objects.new(f'Rueda_{axle}_{side}', None)
        bus_col.objects.link(w)
        w.parent = root
        w.location = (s * 1.255, y, 0.56)
        w.empty_display_size = 0.25
        wheel_roots.append(w)
        torus('Neumático', (0, 0, 0), 0.345, 0.125, rubber, w)
        cylinder('Llanta exterior', (s * 0.075, 0, 0), 0.285, 0.15, rim, 'X', 48, w)
        cylinder('Núcleo oscuro', (s * 0.16, 0, 0), 0.19, 0.035, black, 'X', 40, w)
        cylinder('Buje', (s * 0.185, 0, 0), 0.075, 0.045, rim, 'X', 32, w)
        for k in range(8):
            a = 2 * math.pi * k / 8
            cylinder('Tornillería', (s * 0.19, 0.125 * math.sin(a), 0.125 * math.cos(a)), 0.018, 0.018, rim, 'X', 12, w)
        # Upper semicircular trim seats the wheel without a fake full ring.
        curve = bpy.data.curves.new('Paso de rueda superior', 'CURVE')
        curve.dimensions = '3D'
        curve.bevel_depth = 0.025
        curve.bevel_resolution = 2
        spline = curve.splines.new('POLY')
        steps = 32
        spline.points.add(steps)
        for k in range(steps + 1):
            a = math.pi * k / steps
            spline.points[k].co = (s * 1.29, y + 0.50 * math.cos(a), 0.56 + 0.50 * math.sin(a), 1)
        arch = bpy.data.objects.new('Paso de rueda | arco superior', curve)
        bus_col.objects.link(arch)
        arch.parent = root
        curve.materials.append(black)

# Side identity marks; text local normal is rotated toward each side.
for s in (-1, 1):
    rot = (math.pi / 2, 0, s * math.pi / 2)
    text_obj('Marca lateral', 'ENRUTADOS', (s * 1.333, -0.45, 0.96), 0.16, white, rot)
    text_obj('Descriptor lateral', 'MOVILIDAD CONECTADA', (s * 1.334, 1.60, 0.96), 0.075, cyan, rot)

# Rear treatment.
box('Luna trasera', (0, 4.412, 2.10), (2.10, 0.035, 1.12), glass, 0.09)
box('Tapa motor trasera', (0, 4.43, 1.02), (1.82, 0.04, 0.66), panel, 0.06)
for z in (0.82, 0.92, 1.02, 1.12):
    box('Rejilla trasera', (0, 4.46, z), (1.40, 0.025, 0.025), black, 0.006)
for s in (-1, 1):
    for z in (0.77, 0.96, 1.15):
        box('Farol trasero', (s * 1.02, 4.47, z), (0.16, 0.035, 0.10), red if z < 1.1 else amber, 0.025)
box('Parachoques trasero', (0, 4.39, 0.55), (2.36, 0.16, 0.22), black, 0.06)

# Animation: six seconds, ease in/out, no automatic loop baked into the asset.
root.location = (0, 8.0, 0)
root.keyframe_insert(data_path='location', frame=1)
root.location = (0, 0, 0)
root.keyframe_insert(data_path='location', frame=144)
if root.animation_data and root.animation_data.action:
    root.animation_data.action.name = 'Approach'
for w in wheel_roots:
    w.rotation_euler = (0, 0, 0)
    w.keyframe_insert(data_path='rotation_euler', frame=1)
    w.rotation_euler.x = 8.0 / 0.47
    w.keyframe_insert(data_path='rotation_euler', frame=144)
    if w.animation_data and w.animation_data.action:
        w.animation_data.action.name = 'Approach'

# Studio is retained in the editable source but excluded from the GLB.
ground_mat = material('Studio | suelo', (0.018, 0.023, 0.03), 0.25, 0.32)
box('Studio ground', (0, 0, -0.08), (200, 200, 0.12), ground_mat, 0, None, stage_col)
world = bpy.data.worlds.new('Studio world')
scene.world = world
world.use_nodes = True
world.node_tree.nodes['Background'].inputs['Color'].default_value = (0.055, 0.075, 0.11, 1)
world.node_tree.nodes['Background'].inputs['Strength'].default_value = 0.35


def area(name, loc, energy, color, size):
    data = bpy.data.lights.new(name, 'AREA')
    data.energy = energy
    data.color = color
    data.shape = 'DISK'
    data.size = size
    o = bpy.data.objects.new(name, data)
    stage_col.objects.link(o)
    o.location = loc
    o.rotation_euler = (Vector((0, 0, 1.2)) - o.location).to_track_quat('-Z', 'Y').to_euler()
    return o

area('Key', (4, -6, 8), 1800, (0.68, 0.86, 1.0), 6)
area('Fill', (-5, -2, 4), 1200, (0.2, 0.75, 1.0), 5)
area('Rim', (2, 5, 6), 2100, (0.1, 0.9, 1.0), 4)
area('Front softbox', (0, -8, 3), 650, (1.0, 0.78, 0.55), 3)

cam_data = bpy.data.cameras.new('Review camera')
cam = bpy.data.objects.new('Review camera', cam_data)
stage_col.objects.link(cam)
scene.camera = cam
cam_data.clip_end = 300
scene.render.engine = 'CYCLES'
scene.cycles.samples = 32
scene.cycles.use_denoising = True
scene.render.resolution_x = 1000
scene.render.resolution_y = 750
scene.render.resolution_percentage = 100
scene.render.image_settings.file_format = 'PNG'
scene.view_settings.view_transform = 'AgX'

# Save the review pose, export only the model and its independent animation.
scene.frame_set(144)
bpy.ops.wm.save_as_mainfile(filepath=os.path.join(ASSETS, 'Bus_urbano_fuente.blend'))
bpy.ops.object.select_all(action='DESELECT')
for o in bus_col.objects:
    o.select_set(True)
bpy.context.view_layer.objects.active = root
bpy.ops.export_scene.gltf(
    filepath=os.path.join('/mnt/agents/output', 'Bus_urbano_Enrutados.glb'),
    export_format='GLB',
    use_selection=True,
    export_apply=True,
    export_animations=True,
    export_animation_mode='ACTIVE_ACTIONS',
    export_nla_strips_merged_animation_name='Approach',
    export_frame_range=True,
    export_anim_slide_to_zero=True,
    export_force_sampling=True,
    export_yup=True,
    export_extras=True,
    export_cameras=False,
    export_lights=False,
)

# First vertical-slice render for visual inspection.
cam.location = (7.7, -11.8, 6.0)
target = Vector((0, -0.25, 1.45))
cam.rotation_euler = (target - cam.location).to_track_quat('-Z', 'Y').to_euler()
cam_data.type = 'ORTHO'
cam_data.ortho_scale = 11.8
scene.render.filepath = os.path.join(ASSETS, 'vista_previa.png')
bpy.ops.render.render(write_still=True)
print('BUS_BUILD_COMPLETE')

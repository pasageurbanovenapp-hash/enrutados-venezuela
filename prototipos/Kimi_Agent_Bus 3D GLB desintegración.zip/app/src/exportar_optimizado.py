import bpy, os
from collections import defaultdict

bpy.ops.wm.open_mainfile(filepath='/mnt/agents/output/app/assets/Bus_urbano_fuente.blend')
scene = bpy.context.scene
scene.frame_set(144)
collection = bpy.data.collections.get('BUS • componentes editables')

# The .blend keeps every editable component. The export copy batches only
# siblings that share a parent and material, preserving each wheel hierarchy.
bpy.ops.object.select_all(action='DESELECT')
convert = [o for o in collection.objects if o.type in {'CURVE', 'FONT'}]
for o in convert:
    o.select_set(True)
if convert:
    bpy.context.view_layer.objects.active = convert[0]
    bpy.ops.object.convert(target='MESH')

groups = defaultdict(list)
for o in list(collection.objects):
    if o.type != 'MESH':
        continue
    mat = o.data.materials[0].name if o.data.materials else 'sin_material'
    parent = o.parent.name if o.parent else 'sin_padre'
    groups[(parent, mat)].append(o)

for (parent, mat), objects in groups.items():
    if len(objects) < 2:
        objects[0].name = f'{parent} | {mat}'
        continue
    bpy.ops.object.select_all(action='DESELECT')
    for o in objects:
        o.select_set(True)
    bpy.context.view_layer.objects.active = objects[0]
    bpy.ops.object.join()
    bpy.context.object.name = f'{parent} | {mat}'

bpy.ops.object.select_all(action='DESELECT')
for o in collection.objects:
    o.select_set(True)
root = bpy.data.objects.get('BUS_ROOT • avance -Y')
bpy.context.view_layer.objects.active = root
out = '/mnt/agents/output/Bus_urbano_Enrutados_optimizado.glb'
bpy.ops.export_scene.gltf(
    filepath=out,
    export_format='GLB',
    use_selection=True,
    export_apply=True,
    export_animations=True,
    export_animation_mode='ACTIVE_ACTIONS',
    export_nla_strips_merged_animation_name='Approach',
    export_frame_range=True,
    export_anim_slide_to_zero=True,
    export_force_sampling=True,
    export_yup=True,
    export_extras=True,
    export_cameras=False,
    export_lights=False,
)
print('OPTIMIZED_EXPORT', out, len(collection.objects))

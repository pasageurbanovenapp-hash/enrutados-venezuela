const image = document.querySelector('#model-view');
const tabs = [...document.querySelectorAll('.tab')];

function selectView(tab) {
  tabs.forEach((item) => item.setAttribute('aria-selected', String(item === tab)));
  image.style.opacity = '0';
  const next = new Image();
  next.onload = () => {
    image.src = `./assets/${tab.dataset.image}.png`;
    image.alt = tab.dataset.alt;
    image.style.opacity = '1';
  };
  next.onerror = () => { image.style.opacity = '1'; };
  next.src = `./assets/${tab.dataset.image}.png`;
}

tabs.forEach((tab) => tab.addEventListener('click', () => selectView(tab)));
window.__SCENE_READY__ = true;
window.__seek = () => selectView(tabs[0]);

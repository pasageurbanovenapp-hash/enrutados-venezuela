import bpy, math, os, sys
from mathutils import Vector

args = sys.argv[sys.argv.index('--') + 1:]
group, index = args[0], int(args[1])
bpy.ops.wm.open_mainfile(filepath='/mnt/agents/output/app/assets/Bus_urbano_fuente.blend')
scene = bpy.context.scene
scene.frame_set(144)
scene.render.resolution_x = 800
scene.render.resolution_y = 800
scene.render.resolution_percentage = 100
scene.cycles.samples = 4
scene.render.threads_mode = 'FIXED'
scene.render.threads = 2
cam = scene.camera
cam.data.type = 'ORTHO'
out = '/mnt/agents/output/app/verification-shots'
os.makedirs(out, exist_ok=True)

if group == 'orbit':
    a = math.radians(index * 45)
    target = Vector((0, 0, 1.4))
    cam.location = target + Vector((12.5 * math.sin(a), -12.5 * math.cos(a), 7.0))
    cam.data.ortho_scale = 11.5
elif group == 'top':
    target = Vector((0, 0, 0))
    cam.location = (0, 0, 16)
    cam.data.ortho_scale = 11.2
elif group == 'front':
    angles = [-55, -25, 0, 25, 55]
    a = math.radians(angles[index])
    target = Vector((0, -4.12, 1.65))
    cam.location = target + Vector((4.8 * math.sin(a), -4.8 * math.cos(a), 1.3))
    cam.data.ortho_scale = 3.9
elif group == 'doors':
    angles = [-35, -15, 0, 15, 35]
    a = math.radians(angles[index])
    target = Vector((-1.1, -1.15, 1.55))
    cam.location = target + Vector((-5.8 * math.cos(a), 5.8 * math.sin(a), 1.6))
    cam.data.ortho_scale = 5.1
elif group == 'wheel':
    angles = [-35, -15, 0, 15, 35]
    a = math.radians(angles[index])
    target = Vector((-1.24, -2.78, 0.62))
    cam.location = target + Vector((-2.8 * math.cos(a), 2.8 * math.sin(a), 0.8))
    cam.data.ortho_scale = 1.9

cam.rotation_euler = (target - cam.location).to_track_quat('-Z', 'Y').to_euler()
scene.render.filepath = os.path.join(out, f'{group}_{index}.png')
bpy.ops.render.render(write_still=True)
print(scene.render.filepath)
